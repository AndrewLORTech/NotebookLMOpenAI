import React, { useState } from 'react';
import axios from 'axios';

const api = import.meta.env.VITE_API_URL;

export default function NotebookApp() {
  const [notebookId, setNotebookId] = useState("demo");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [uploadText, setUploadText] = useState("");
  const [pdf, setPdf] = useState(null);
  const [citations, setCitations] = useState([]);

  const handleAsk = async () => {
    const res = await axios.post(`${api}/ask`, {
      question,
      notebook_id: notebookId,
    });
    setAnswer(res.data.answer);
    setCitations(res.data.citations);
  };

  const handleTextUpload = async () => {
    await axios.post(`${api}/upload`, { text: uploadText });
    alert("Text uploaded.");
  };

  const handlePDFUpload = async () => {
    const formData = new FormData();
    formData.append("notebook_id", notebookId);
    formData.append("file", pdf);
    await axios.post(`${api}/upload-pdf`, formData);
    alert("PDF uploaded.");
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-blue-700">📘 NotebookLM (OpenAI)</h1>

      <input
        value={notebookId}
        onChange={(e) => setNotebookId(e.target.value)}
        placeholder="Notebook ID"
        className="w-full p-2 border mb-4"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <textarea
            value={uploadText}
            onChange={(e) => setUploadText(e.target.value)}
            placeholder="Paste raw text..."
            className="w-full border p-2 h-32"
          />
          <button onClick={handleTextUpload} className="bg-blue-600 text-white px-4 py-2 mt-2">Upload Text</button>
        </div>

        <div>
          <input type="file" accept="application/pdf" onChange={(e) => setPdf(e.target.files[0])} />
          <button onClick={handlePDFUpload} className="bg-purple-600 text-white px-4 py-2 mt-2 ml-2">Upload PDF</button>
        </div>
      </div>

      <input
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Ask a question..."
        className="w-full border p-2 mb-2"
      />
      <button onClick={handleAsk} className="bg-green-600 text-white px-4 py-2">Ask</button>

      <div className="mt-6 border p-4 rounded shadow bg-gray-50">
        <h2 className="font-bold mb-2">🧠 Answer:</h2>
        <p className="whitespace-pre-line">{answer}</p>

        {citations.length > 0 && (
          <div className="mt-4 text-sm text-gray-600">
            <h3 className="font-semibold">📚 Sources:</h3>
            <ul>
              {citations.map((c, i) => <li key={i}>[{i + 1}] {c}</li>)}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
