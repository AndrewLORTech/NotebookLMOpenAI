import NotebookApp from "./components/NotebookApp";

function App() {
  return <NotebookApp />;
}

export default App;
